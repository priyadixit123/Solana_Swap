use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
 use anchor_lang::prelude::{ /* … */ Sysvar, Rent };
 


 
// This is your program's public key and it will update
// automatically when you build the project.
declare_id!("4fiqwXAjcPB2cUrN4Aj2TjnBhAhHobJPo8ezCBVW2z7K");

#[program]
pub mod token_swap {
    use super::*;
     pub fn initialize_pool(ctx: Context<InitializePool>) -> Result<()> {
    let pool_account = &mut ctx.accounts.pool;

    // Now these compile, because `vault_a` & `vault_b` exist on the context
    pool_account.vault_a = ctx.accounts.vault_a.key();
    pool_account.vault_b = ctx.accounts.vault_b.key();

    Ok(())
}

    pub fn swap_token (ctx: Context<Swap>, amount_in: u64,) -> Result<()> 
    {
        let rate = 2 ;
        let _amount_out = amount_in * rate;
        token::transfer(ctx.accounts.transfer_a_ctx(), amount_in,)?;

        Ok(())
    }
     
}

 #[derive(Accounts)]
pub struct InitializePool<'info> {
    /// The on‐chain pool account we’re creating
    #[account(init, payer = user, space = 8 + std::mem::size_of::<Pool>())]
    pub pool: Account<'info, Pool>,

    /// CHECK: this PDA will be the vault for token A
    #[account(mut)]
    pub vault_a: UncheckedAccount<'info>,

    /// CHECK: this PDA will be the vault for token B
    #[account(mut)]
    pub vault_b: UncheckedAccount<'info>,

    /// The user who pays for the init
    #[account(mut)]
    pub user: Signer<'info>,

    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Swap<'info>{
    #[account(mut)]
    pub user_authority: Signer<'info>,


    #[account(mut)]
    pub user_token_a:  Account<'info, TokenAccount>,
    #[account(mut)]
    pub user_token_b:  Account<'info, TokenAccount>,

    #[account(mut)]
    pub  vault_a:  Account<'info, TokenAccount>,
    #[account(mut)]
    pub  vault_b:  Account<'info, TokenAccount>,

    pub token_program:Program<'info,Token>,

}

impl<'info>Swap<'info> {

    fn transfer_a_ctx(&self) -> CpiContext<'_, '_, '_, 'info,Transfer<'info>>{
        let cpi_accounts = Transfer {
            from: self.user_token_a.to_account_info(),
            to:self.vault_a.to_account_info(),
            authority:self.user_authority.to_account_info(), 
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)

    }

     fn _transfer_b_ctx(&self) -> CpiContext<'_, '_, '_, 'info, Transfer<'info>>{
        let cpi_accounts = Transfer {
            from: self.user_token_b.to_account_info(),
            to:self.vault_b.to_account_info(),
            authority:self.user_authority.to_account_info(), 
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)

    }

}

#[account]
pub struct SwapPool {
     pub authority :Pubkey,
     
    pub token_a :Pubkey,
    pub token_b :Pubkey,
    pub vault_a :Pubkey,
    pub vault_b :Pubkey,
    pub bump :u8,

}

#[account]
pub struct Pool {
    // your other fields…
    pub vault_a: Pubkey,
    pub vault_b: Pubkey,
    // …
}